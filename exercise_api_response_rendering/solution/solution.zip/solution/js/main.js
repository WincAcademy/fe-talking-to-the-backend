import { addEventListeners } from "./events.js";
addEventListeners();